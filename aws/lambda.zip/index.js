const client = require('https');
const { URL } = require('url');

const TIMEOUT_MS = 10000;

const postToUrl = (url, data) => {
  return new Promise((resolve, reject) => {
    const parsedUrl = new URL(url);
    const postData = JSON.stringify(data);

    const req = client.request({
      hostname: parsedUrl.hostname,
      port: 443,
      path: parsedUrl.pathname + parsedUrl.search,
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      },
      timeout: TIMEOUT_MS
    }, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        if (res.statusCode >= 200 && res.statusCode < 300) {
          resolve({ statusCode: res.statusCode, body });
        } else {
          reject(new Error('HTTP ' + res.statusCode + ': ' + body));
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => {
      req.destroy();
      reject(new Error('Request timeout'));
    });
    req.write(postData);
    req.end();
  });
};

exports.handler = async (event) => {
  console.log('Received event:', JSON.stringify(event, null, 2));

  const urls = process.env.EXTERNAL_API_URLS
    ? process.env.EXTERNAL_API_URLS.split(',').filter(u => u.trim())
    : [];

  if (urls.length === 0) {
    console.warn('No external API URLs configured');
  }

  for (const record of event.Records) {
    const body = JSON.parse(record.body);
    console.log('Processing message:', JSON.stringify(body, null, 2));

    // EventBridge経由のAuth0イベントからuser_idとblockedを抽出
    const detail = body.detail || {};
    const data = detail.data?.object || {};
    const payload = {
      user_id: data.user_id,
      blocked: data.blocked
    };
    console.log('Extracted payload:', JSON.stringify(payload, null, 2));

    const results = await Promise.allSettled(
      urls.map(url => postToUrl(url.trim(), payload))
    );

    const failures = results.filter(r => r.status === 'rejected');
    if (failures.length > 0) {
      console.error('Failed requests:', failures.map(f => f.reason.message));
      throw new Error(failures.length + '/' + urls.length + ' requests failed');
    }

    console.log('Message processed successfully');
  }

  return { statusCode: 200, body: 'OK' };
};
